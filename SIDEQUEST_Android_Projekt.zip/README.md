# SIDEQUEST – Real Life. Game Mode.

SIDEQUEST macht aus dem Alltag ein kleines Open-World-Spiel: Die App schlägt kleine reale Mini-Abenteuer vor, die du erledigen und mit XP belohnen kannst.

## Funktionen
- zufällig generierte Sidequest-Karten aus einem kuratierten Quest-Pool
- Quest-Kategorien, Dauer und XP-Belohnungen
- Quests abschließen und Erfahrung sammeln
- Levelsystem mit Fortschrittsanzeige
- Quest-Archiv / persönliche Story
- futuristisches Neon-Dark-Design
- lokale Speicherung via Android DataStore
- offline nutzbar, kein Konto, keine Werbung, keine Internetberechtigung

## Build
1. ZIP entpacken.
2. Ordner in Android Studio öffnen.
3. JDK 17 und Android SDK 35 installieren.
4. Gradle-Synchronisierung abwarten.
5. Android-Gerät oder Emulator verbinden und Run drücken.

## App-ID
`de.sidequest.app`

Hinweis: Der Quest-Pool ist in der App lokal hinterlegt. Das Projekt ist Quellcode und muss in Android Studio zur APK gebaut werden. Es wurde in dieser Umgebung nicht auf einem Gerät kompiliert.
