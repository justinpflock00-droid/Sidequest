package de.sidequest.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

private val android.content.Context.store by preferencesDataStore(name = "sidequest")
private val night = Color(0xFF090914)
private val card = Color(0xFF17172A)
private val pink = Color(0xFFFF4F9A)
private val blue = Color(0xFF55D9FF)
private val lime = Color(0xFFC7FF67)
private val dim = Color(0xFFAAAAC1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SideQuestApp() }
    }
}

data class Quest(val title: String, val detail: String, val time: String, val xp: Int, val category: String, val icon: String)

private val quests = listOf(
    Quest("Finde eine Farbe", "Such dir eine Farbe aus und entdecke fünf Dinge in deiner Umgebung, die du sonst übersehen würdest.", "5 MIN", 30, "BEOBACHTEN", "👁️"),
    Quest("Der Soundtrack-Moment", "Geh ans Fenster oder vor die Tür. Hör einen Song und beobachte die Welt, als wäre sie eine Filmszene.", "1 SONG", 35, "VIBE", "🎧"),
    Quest("Mini-Mutprobe", "Tu eine kleine Sache, die du schon länger aufschiebst. Nicht perfekt. Einfach anfangen.", "10 MIN", 50, "MUT", "⚡"),
    Quest("Foto ohne Zweck", "Mach ein Foto von etwas völlig Alltäglichem – aber aus einer Perspektive, die du noch nie benutzt hast.", "3 MIN", 25, "KREATIV", "📸"),
    Quest("NPC wird Hauptfigur", "Frag jemanden ehrlich, wie sein Tag läuft, und hör eine Minute wirklich zu.", "5 MIN", 60, "SOCIAL", "🗣️"),
    Quest("Gedanken-Download", "Schreib drei Minuten alles auf, was gerade in deinem Kopf herumliegt. Ohne Sortieren und ohne Zensur.", "3 MIN", 30, "RESET", "🧠"),
    Quest("Die unbekannte Route", "Geh eine kurze Strecke auf einem sicheren, öffentlichen Weg, den du sonst nicht nimmst.", "10 MIN", 45, "EXPLORE", "🧭"),
    Quest("Upgrade dein Nest", "Verbessere eine kleine Ecke deines Zimmers so, dass du dich dort wohler fühlst.", "10 MIN", 40, "UPGRADE", "🛠️"),
    Quest("Wasser-Checkpoint", "Trink ein Glas Wasser, streck dich und atme zehnmal langsam durch. Ein simpler Reset.", "2 MIN", 15, "RESET", "💧"),
    Quest("Lern einen Random-Fact", "Lerne etwas Neues über ein Thema, das du normalerweise nie anklickst. Erklär es danach in einem Satz.", "8 MIN", 35, "WISSEN", "🛸"),
    Quest("Mach jemandem den Tag", "Schick eine ehrliche nette Nachricht oder sag jemandem etwas Wertschätzendes.", "2 MIN", 45, "SOCIAL", "💌"),
    Quest("Bossfight: 15 Minuten", "Wähle eine Aufgabe, die du vermeiden willst. Stell 15 Minuten und arbeite nur daran.", "15 MIN", 75, "BOSS", "👾"),
    Quest("Offline-Detox", "Leg dein Handy für zehn Minuten weg und mach etwas mit deinen Händen.", "10 MIN", 40, "RESET", "🌱"),
    Quest("Memory unlocked", "Schreib eine schöne oder absurde Erinnerung auf, die du nicht vergessen möchtest.", "4 MIN", 30, "KREATIV", "✨")
)

@Composable
fun SideQuestApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf(quests.random()) }
    var xp by remember { mutableIntStateOf(0) }
    var completed by remember { mutableStateOf(listOf<String>()) }
    var history by remember { mutableStateOf(listOf<String>()) }
    var filter by remember { mutableStateOf("ALLE") }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val p = context.store.data.first()
        xp = p[intPreferencesKey("xp")] ?: 0
        completed = try { val a=JSONArray(p[stringPreferencesKey("completed")] ?: "[]"); (0 until a.length()).map { a.getString(it) } } catch (_:Exception) { emptyList() }
        history = try { val a=JSONArray(p[stringPreferencesKey("history")] ?: "[]"); (0 until a.length()).map { a.getString(it) } } catch (_:Exception) { emptyList() }
        loaded = true
    }
    fun save() {
        scope.launch {
            context.store.edit { p ->
                p[intPreferencesKey("xp")] = xp
                p[stringPreferencesKey("completed")] = JSONArray(completed).toString()
                p[stringPreferencesKey("history")] = JSONArray(history).toString()
            }
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(background=night, surface=card, primary=pink, secondary=blue, onBackground=Color.White, onSurface=Color.White)) {
        Scaffold(containerColor=night, bottomBar={
            NavigationBar(containerColor=Color(0xFF111122)) {
                listOf("Portal","Archiv","Level").forEachIndexed { i, label ->
                    NavigationBarItem(selected=tab==i, onClick={tab=i}, icon={
                        Icon(when(i){0->Icons.Default.Explore;1->Icons.Default.Inventory2;else->Icons.Default.EmojiEvents},null)
                    }, label={Text(label,fontSize=10.sp)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=pink, selectedTextColor=pink, indicatorColor=Color(0xFF33203A), unselectedIconColor=dim, unselectedTextColor=dim))
                }
            }
        }) { pad ->
            if (!loaded) Box(Modifier.fillMaxSize().padding(pad), contentAlignment=Alignment.Center) { CircularProgressIndicator(color=pink) }
            else Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp)) {
                Header(xp)
                when(tab) {
                    0 -> Portal(current, completed, { current = quests.filter { it.title != current.title }.random() }, {
                        if(current.title !in completed) {
                            completed = completed + current.title
                            xp += current.xp
                            history = listOf(current.title) + history
                            save()
                            current = quests.filter { it.title !in completed }.ifEmpty { quests }.random()
                        }
                    })
                    1 -> ArchiveScreen(history)
                    else -> LevelScreen(xp, completed.size)
                }
            }
        }
    }
}

@Composable
fun Header(xp: Int) {
    Row(Modifier.fillMaxWidth().padding(top=15.dp,bottom=15.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(pink,blue)), RoundedCornerShape(14.dp)), contentAlignment=Alignment.Center) {
            Icon(Icons.Default.Bolt,null,tint=night,modifier=Modifier.size(28.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("SIDEQUEST",fontWeight=FontWeight.Black,fontSize=19.sp,letterSpacing=2.sp)
            Text("REAL LIFE. GAME MODE.",fontSize=8.sp,color=dim,letterSpacing=1.5.sp)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment=Alignment.End) {
            Text("$xp XP",color=lime,fontWeight=FontWeight.Bold)
            Text("DEIN SCORE",fontSize=8.sp,color=dim)
        }
    }
}

@Composable
fun Portal(q: Quest, completed: List<String>, reroll: ()->Unit, finish: ()->Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("DEIN ALLTAG, ABER",color=blue,fontSize=10.sp,letterSpacing=2.sp)
        Text("mit Plot-Twist.",fontSize=30.sp,fontWeight=FontWeight.Black)
        Text("Zieh eine Sidequest. Mach aus einem normalen Moment eine Story.",color=dim,fontSize=13.sp)
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().weight(1f).background(Brush.linearGradient(listOf(Color(0xFF29152F),Color(0xFF14283B),Color(0xFF17231D))),RoundedCornerShape(26.dp)).border(1.dp,Color(0xFF65405F),RoundedCornerShape(26.dp)).padding(20.dp)) {
            Column(Modifier.fillMaxSize(), verticalArrangement=Arrangement.SpaceBetween) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text("⚡  RANDOM DROP",color=lime,fontSize=10.sp,letterSpacing=2.sp,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text(q.category,color=blue,fontSize=9.sp)
                }
                Column {
                    Text(q.icon,fontSize=48.sp)
                    Spacer(Modifier.height(12.dp))
                    Text(q.title,fontSize=28.sp,fontWeight=FontWeight.Black,lineHeight=32.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(q.detail,fontSize=15.sp,color=Color(0xFFD6D5E7),lineHeight=22.sp)
                }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    MetaChip(Icons.Default.Schedule,q.time)
                    Spacer(Modifier.width(8.dp))
                    MetaChip(Icons.Default.Bolt,"+${q.xp} XP")
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick=finish,enabled=q.title !in completed,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=lime,contentColor=night,disabledContainerColor=Color(0xFF343447),disabledContentColor=dim)) {
            Icon(Icons.Default.CheckCircle,null); Spacer(Modifier.width(8.dp)); Text(if(q.title in completed) "QUEST ERLEDIGT" else "QUEST ABSCHLIESSEN",fontWeight=FontWeight.Black,letterSpacing=1.sp)
        }
        OutlinedButton(onClick=reroll,modifier=Modifier.fillMaxWidth().padding(bottom=10.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.outlinedButtonColors(contentColor=blue)) {
            Icon(Icons.Default.Casino,null); Spacer(Modifier.width(8.dp)); Text("Andere Quest ziehen")
        }
    }
}

@Composable
fun MetaChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Row(Modifier.background(Color(0x66303048),RoundedCornerShape(50)).padding(horizontal=12.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
        Icon(icon,null,tint=blue,modifier=Modifier.size(14.dp)); Spacer(Modifier.width(5.dp)); Text(label,fontSize=11.sp,color=Color.White)
    }
}

@Composable
fun ArchiveScreen(history: List<String>) {
    Column(Modifier.fillMaxSize()) {
        Text("Deine Story",fontSize=28.sp,fontWeight=FontWeight.Black)
        Text("Jede erledigte Quest ist ein Moment, den du selbst gestartet hast.",color=dim,fontSize=13.sp)
        Spacer(Modifier.height(18.dp))
        if(history.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("📼",fontSize=44.sp); Text("Noch keine Kapitel",fontWeight=FontWeight.Bold)
                    Text("Deine erledigten Quests landen hier.",color=dim,fontSize=12.sp)
                }
            }
        } else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)) {
            items(history) { title ->
                Row(Modifier.fillMaxWidth().background(card,RoundedCornerShape(14.dp)).padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.DoneAll,null,tint=lime); Spacer(Modifier.width(12.dp)); Text(title,fontWeight=FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun LevelScreen(xp: Int, count: Int) {
    val level = xp / 200 + 1
    val progress = (xp % 200) / 200f
    Column(Modifier.fillMaxSize()) {
        Text("Charakterprofil",fontSize=28.sp,fontWeight=FontWeight.Black)
        Text("Du levelst nicht durch Perfektion. Du levelst durchs Erleben.",color=dim,fontSize=13.sp)
        Spacer(Modifier.height(22.dp))
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF30203D),Color(0xFF162C3B))),RoundedCornerShape(24.dp)).padding(20.dp)) {
            Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxWidth()) {
                Box(Modifier.size(104.dp).border(2.dp,pink,CircleShape).background(Color(0xFF21172F),CircleShape),contentAlignment=Alignment.Center) {
                    Text("$level",fontSize=44.sp,fontWeight=FontWeight.Black,color=lime)
                }
                Spacer(Modifier.height(12.dp))
                Text("LEVEL $level",fontSize=12.sp,color=blue,letterSpacing=3.sp,fontWeight=FontWeight.Bold)
                Text("$xp XP GESAMT",fontSize=24.sp,fontWeight=FontWeight.Black)
                Spacer(Modifier.height(16.dp))
                LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth().height(8.dp),color=pink,trackColor=Color(0xFF49344F))
                Spacer(Modifier.height(6.dp))
                Text("${xp%200} / 200 XP bis Level ${level+1}",color=dim,fontSize=11.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            ProfileStat("QUESTS", "$count", Modifier.weight(1f))
            ProfileStat("XP NÄCHSTES LEVEL", "${200-(xp%200)}", Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Text("DIE REGEL",color=lime,fontSize=10.sp,letterSpacing=2.sp)
        Text("Keine Strafen. Keine verlorenen Streaks. Kein Druck. SIDEQUEST soll dein Leben größer machen – nicht deine To-do-Liste.",color=dim,fontSize=14.sp,lineHeight=21.sp)
    }
}

@Composable
fun ProfileStat(label:String,value:String,modifier:Modifier) {
    Column(modifier.background(card,RoundedCornerShape(16.dp)).padding(15.dp)) {
        Text(label,color=dim,fontSize=9.sp,letterSpacing=1.sp); Text(value,fontSize=26.sp,fontWeight=FontWeight.Bold,color=blue)
    }
}
